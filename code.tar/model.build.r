
# date: 11/11/2014 
# aim: 
#  - for a gene of example (ID2199), fit null and full models.
#  
#  Null models are fit by robust linear regression. 
#
#  For full models, extra-sample prediction error is estimated by repeated (R=10) K-fold (K=5)
#  cross-validation.
#
#  Regression coefficients are stabilized by ridge penalty regularization
#  (by cv.glmnet() in glmnet package with alpha=0 and nfolds=3)
#
#  The script returns the average and standard error of a predictor's coefficient in a model.
#  The average coefficient is computed overall cross-validated folds and 
#  the standard error of the average coefficient is computed by dividing 
#  standard error of the coefficient overall folds by the number of folds.
#  This information may be useful to evaluate coefficients stability.
# 
#  Missing data are imputed, separately in training and test subsets
#  Here the script requires a maximal number of invalid entries of 5. 
#  Otherwise prediction assessment on heavily imputed data is hardly possible. 
#
#  In order to create diagnostic plots, the script also returns the K*R 
#  fitted values for each response value of a gene in a cell line.
#
# - show diagnostic plots of fitted models for the gene of example 
#
# return: 
# - ridge.penalty.glmnet.rlm.max5nas.iBAQ.summary.txt
# - ridge.penalty.glmnet.rlm.max5nas.iBAQ.stability.txt
# - ridge.penalty.glmnet.rlm.max5nas.iBAQ.fitted.txt
# - NCI60.model.dx.plot.pdf


require(GenomicRanges)
require(cvTools)
require(impute)
require(nortest)


load("NCI60.dataset.rda")
load("summarizedExperimentiBAQ.rda")
load("CISBP-RNA.rda")
load("NCI60.annotation.rda")


source("auxiliary.functions.r")


# obtain RBP->target interactions (binary value 1/0)
rbp.db=read.delim("NCI60.rbp.target.binary.txt",
 header=TRUE,as.is=TRUE,sep="\t")

# obtain details on RBP->target interactions
rbp.f=read.delim("NCI60.rbp.target.best.site.qv.txt",
 header=T,as.is=T,sep="\t")

# obtain NCI-60 protein data
exprm = as.matrix(assays(sset)[[2]])
ind = apply(exprm, 1, function(x) all(is.na(x)))
# remove N/A rows inserted in the construction of summarizedExperiment object
exprm = exprm[!ind,]
# rename protein data
prot.exprm=exprm


# select genes with a maximum number of 5 NAs
NAs=as.numeric(apply(prot.exprm,1,function(x)(length(x[is.na(x)==T]))))
prot.exprm=prot.exprm[NAs<=5,]

# obtain RBP protein data
rbp.prot=prot.exprm[is.na(match(rownames(prot.exprm),
 annotation$ID[is.na(match(annotation$HGNC.symbol,rbp.pwm))==FALSE]))==FALSE,]


# obtain RNA data
exprm = as.matrix(assays(sset)[[1]])
ind = apply(exprm, 1, function(x) all(is.na(x)))
exprm = exprm[!ind,]
rna.exprm=exprm

# summary of prediction error estimates achieved by M0 and M1
RCV <- data.frame(t(rep(NA,14)))
RCVcolnames <- c("ID","HGNC.symbol","m0.rmspe","m1.rmspe",
 "m0.coef.n","m1.coef.n",
 "cvm","cvsd","lambda.min",
 "rmspe.ratio","m0.rmspe.avg","m1.rmspe.avg",
 "rmspe.ratio.avg","n.iter")
RCV <- RCV[-1,]

FITS <- data.frame(t(rep(NA,6)))
FITScolnames <-c("ID","HGNC.symbol","Cell.line","Y","m0.fitted","m1.fitted")
FITS <- FITS[-1,]

COEF <- data.frame(t(rep(NA,11)))
COEFcolnames <- c("ID","HGNC.symbol","rmspe.ratio.avg","initial.predictor.n",
 "selected.predictor.n","predictor","estimate","estimate.sd","best.site.qv",
 "cor.estimate.best.site.qv","cor.pv")
COEF <- COEF[-1,]

# select proteins corresponding to inferred RBP targets
tmp=annotation$ID[is.na(match(annotation$HGNC.symbol,rownames(rbp.db)))==FALSE]
targetIDs = rownames(prot.exprm)[is.na(match(rownames(prot.exprm),tmp))==FALSE]


#---------------------
#
# case study 
#
#---------------------
targetID = "ID2199"

#----------------------
# make predictor matrix for full model (RNA level + RBP protein levels by sample) 

# RBPs inferred to bind either mRNA UTRs of the target model
# from the database of computationally inferred RBP/target interactions 
tmp=colnames(rbp.db)[rbp.db[match(annotation$HGNC.symbol[match(targetID,
 annotation$ID)],rownames(rbp.db)),]==1]
rbp=intersect(annotation$ID[is.na(match(annotation$HGNC.symbol,
 tmp))==FALSE],rownames(rbp.prot))

# predictors for the target model 
if(length(rbp)>0){ predictors=c("rna",rbp) }
if(length(rbp)==0){ predictors="rna" }

# define predictor matrix of the target model
X1=matrix(0,nrow=dim(exprm)[2],ncol=length(predictors),
 dimnames=list(colnames(rbp.prot),predictors))
# RNA abundance
X1[,1]=t(rna.exprm[is.na(match(rownames(rna.exprm),targetID))==FALSE,])
# protein abundances of RBPs inferred to bind the target model
X1[,2:dim(X1)[2]]=t(rbp.prot[is.na(match(rownames(rbp.prot),rbp))==FALSE,])

#----------------------
# predictor for the null model (RNA level)

X0=as.numeric(t(rna.exprm[match(targetID,rownames(rna.exprm)),]))

#----------------------
# make response (protein levels of the target model in 12 tissues)

Y=as.numeric(t(prot.exprm[match(targetID,rownames(prot.exprm)),]))

#----------------------
# standardize variables
for(c in 1 : dim(X1)[2]){
 X1[,c][is.na(X1[,c])==F]=(X1[,c][is.na(X1[,c])==F]-
  mean(X1[,c][is.na(X1[,c])==F]))/sd(X1[,c][is.na(X1[,c])==F])
}
X0 = (X0-mean(X0[is.na(X0)==F]))/sd(X0[is.na(X0)==F])
Y[is.na(Y)==F] = (Y[is.na(Y)==F]-mean(Y[is.na(Y)==F]))/sd(Y[is.na(Y)==F])


#---------------------
#
# build model and assess prediction error by k-fold cross-validation
#
#---------------------
 
K=5; R=10 
 
cv <- cross_validation_with_penalty_tunel(K=K,R=R,X0=X0,X1=X1,Y=Y,penalty=0)

if(is.list(cv[[1]])==TRUE) {
 RCV=rbind(RCV,cbind(as.character(targetID),
  as.character(annotation$HGNC.symbol[match(targetID,annotation$ID)]),
  cv[[1]]$m0.rmspe,cv[[1]]$m1.rmspe,
  cv[[1]]$m0.coef.n,cv[[1]]$m1.coef.n,cv[[1]]$cvm,cv[[1]]$cvsd,
  cv[[1]]$lambda.min,cv[[1]]$rmspe.ratio,
  cv[[1]]$m0.rmspe.avg,cv[[1]]$m1.rmspe.avg,
  cv[[1]]$rmspe.ratio.avg,
  cv[[1]]$n.iter))

 FITS=rbind(FITS,cbind(as.character(targetID),
   as.character(annotation$HGNC.symbol[match(targetID,annotation$ID)]),
   cv[[3]],cv[[4]][,2],cv[[5]][,2]))

 # analyze coefficients of predictors
 vars = unique(unlist(lapply(cv[[2]],function(x)(names(x)))))
 vars = vars[grepl("Intercept",vars)==F]
 m=matrix(nrow=length(cv[[2]]),ncol=length(vars),
  dimnames=list(1:length(cv[[2]]),vars))
 for(j in 1 : length(cv[[2]])){
  tmp=cv[[2]][[j]][grepl("Intercept",names(cv[[2]][[j]]))==F]
  m[j,match(names(tmp),colnames(m))]=as.numeric(tmp)
 } 

 # calculate mean coefficients and SE of the mean overall repeated folds
 estimate=signif(apply(m,2,function(x) (mean(x[is.na(x)==F]))),digits=3)
 estimate.sd=signif(apply(m,2,function(x) (sd(x[is.na(x)==F])))/
  sqrt(apply(m,2,function(x) (length(x[is.na(x)==F])))), digits=3)

 # replace predictors internal IDs with HGNC symbols
 predictors=c(length(vars))
 predictors[is.na(match(vars,"rna"))==F]="rna" 
 predictors[is.na(match(vars,"rna"))==T] = paste(
  vars[is.na(match(vars,"rna"))==T],
  annotation$HGNC.symbol[match(vars[is.na(match(vars,
  "rna"))==T],annotation$ID)],sep="|")
  
 # q-value of the best site predicted between each RBP predictor and the gene
 site.qv=c()
 site.qv["rna"]=NA
 for(j in 2 : length(predictors)){
  site.qv[predictors[j]] = rbp.f[match(
   annotation$HGNC.symbol[match(targetID,annotation$ID)],
   rownames(rbp.f)),match(gsub(".*\\|","",predictors[j]),colnames(rbp.f))]
 }

 # correlation between predictors coefficients and best MEME site q-values
 cor=signif(cor.test(site.qv[2:length(site.qv)],
  estimate[2:length(estimate)])$estimate,digits=3)
 cor.pv=signif(cor.test(site.qv[2:length(site.qv)],
  estimate[2:length(estimate)])$p.value,digits=3)

 COEF=rbind(COEF,cbind(as.character(targetID),
  as.character(annotation$HGNC.symbol[match(targetID,annotation$ID)]),
  cv[[1]]$rmspe.ratio.avg,length(predictors),length(predictors),
  predictors,estimate,estimate.sd,site.qv,cor,cor.pv))

}
colnames(RCV) = RCVcolnames
colnames(COEF) = COEFcolnames
colnames(FITS) = FITScolnames

write.table(RCV,file="ridge.penalty.glmnet.rlm.max5nas.iBAQ.summary.txt",quote=F,row.names=F,col.names=RCVcolnames,sep="\t")
write.table(COEF,file="ridge.penalty.glmnet.rlm.max5nas.iBAQ.stability.txt",quote=F,row.names=F,col.names=COEFcolnames,sep="\t")
write.table(FITS,file="ridge.penalty.glmnet.rlm.max5nas.iBAQ.fitted.txt",quote=F,row.names=F,col.names=FITScolnames,sep="\t")


#------------------------------
#
# diagnostic plots
#
#------------------------------

# M0,M1 fitted values are necessary for diagnostic plots
models = data.frame(ID=FITS$ID,cl=FITS$Cell.line, m0.fitted=FITS$m0.fitted,
 m1.fitted=FITS$m1.fitted,response=FITS$Y)

pdf("NCI60.model.dx.plot.pdf",width=10)
par(mfrow=c(3,6))

 hgnc=annotation$HGNC.symbol[match(targetID,annotation$ID)]

 # RNA levels 
 X0=as.numeric(t(rna.exprm[match(targetID,rownames(rna.exprm)),]))

 # PROT levels
 Y=as.numeric(t(prot.exprm[match(targetID,rownames(prot.exprm)),]))

 # replace NA values with closest non-NA values 
 if(length(Y[is.na(Y)==T])>0){Y=na_impute_for_vector(Y)}
 if(length(X0[is.na(X0)==T])>0){X0=na_impute_for_vector(X0)}

 # standardize variables
 X0 = (X0-mean(X0[is.na(X0)==F]))/sd(X0[is.na(X0)==F])
 Y = (Y-mean(Y))/sd(Y)
 
 # calculate RNA vs PROT correlation
 prot.rna.cor=signif(cor.test(Y,X0,method="spearman")$estimate,digits=2)

 # subset model performances for the gene of interest
 # in order to acquire the fitted values for each cell line 
 m=models[is.na(match(models$ID,targetID))==F,]
 lines = unique(m$cl)

 # calculate the standardized M1 residuals
 fitted.m1.by.line = list(); response.by.line = c();
 residuals.m1.by.line = list(); std.residuals.m1.by.line = list();
 for(l in 1 : length(lines)){
  fitted.m1.by.line[[lines[l]]] = unique(as.numeric(as.vector(m$m1.fitted[is.na(match(m$cl,lines[l]))==F])))
  response.by.line[lines[l]] = unique(as.numeric(as.character(m$response[is.na(match(m$cl,lines[l]))==F][1])))
  residuals.m1.by.line[[lines[l]]] = fitted.m1.by.line[[lines[l]]]-response.by.line[lines[l]] 
 }
 rmse.m1=sqrt(sum(unlist(residuals.m1.by.line)^2)/dim(m)[1])
 for(l in 1 : length(lines)){
  std.residuals.m1.by.line[[lines[l]]] = residuals.m1.by.line[[lines[l]]] / rmse.m1
 }

 # test normality of M1 residuals
 norm.std.residuals.m1.pv = signif(ad.test(unlist(std.residuals.m1.by.line))$p.value,digits=2)

 # calculate the standardized M0 residuals
 fitted.m0.by.line = list(); response.by.line = c();
 residuals.m0.by.line = list(); std.residuals.m0.by.line = list();
 for(l in 1 : length(lines)){
  fitted.m0.by.line[[lines[l]]] = unique(as.numeric(as.vector(m$m0.fitted[is.na(match(m$cl,lines[l]))==F])))
  response.by.line[lines[l]] = unique(as.numeric(as.character(m$response[is.na(match(m$cl,lines[l]))==F][1])))
  residuals.m0.by.line[[lines[l]]] = fitted.m0.by.line[[lines[l]]]-response.by.line[lines[l]]
 }
 rmse.m0=sqrt(sum(unlist(residuals.m0.by.line)^2)/dim(m)[1])
 for(l in 1 : length(lines)){
  std.residuals.m0.by.line[[lines[l]]] = residuals.m0.by.line[[lines[l]]] / rmse.m0
 }

 # test normality of M0 residuals
 norm.std.residuals.m0.pv = signif(ad.test(unlist(std.residuals.m0.by.line))$p.value,digits=2)

 # plot M1 fitted values (X-axis) vs standardized residuals of M1 (Y-axis)  
 plot(unlist(fitted.m1.by.line),unlist(std.residuals.m1.by.line),ylim=c(-2.5,2.5),
  main=paste(targetID,hgnc,sep="|"),cex=.5,pch=19,cex.main=.85,
  xlab="fitted.m1",ylab="std.residuals.m1",las=2,col=rgb(1,0,0,.25))
 abline(h=0,lty=2,lwd=1.5)
 mtext(side=3, line=.5, text=paste("RMSPE ratio=",
  RCV$rmspe.ratio.avg[match(hgnc,RCV$HGNC.symbol)],sep=""),
  cex=.65,adj=.25)
 
 # plot response (X-axis) vs M1 fitted (Y-axis)
 plot(rep(response.by.line[1], length(fitted.m1.by.line[[1]])), fitted.m1.by.line[[1]], 
  cex=.5,pch=19,col=rgb(1,0,0,.25),axes=T, ylab="fitted.m1", xlab="response",
  main=paste(targetID,hgnc,sep="|"),cex.main=.85,las=2,
  xlim=c(min(response.by.line)-.5,max(response.by.line)+.5),
  ylim=c(min(unlist(fitted.m1.by.line)),max(unlist(fitted.m1.by.line))))
  for(l in 2 : length(lines)){
  points(rep(response.by.line[l],length(fitted.m1.by.line[[l]])), fitted.m1.by.line[[l]],
   cex=.5, pch=19,col=rgb(1,0,0,.25))
 }

 # M1 QQ-plot
 qqnorm(unlist(std.residuals.m1.by.line),xlab="normal.scores",ylab="std.residuals.m1",
  cex.main=.75,las=2,col=rgb(1,0,0,.25),main=paste(targetID,hgnc,sep="|"),
  cex=.5,pch=19)
 qqline(unlist(std.residuals.m1.by.line), col = rgb(1,0,0,.25))
 mtext(side=3, line=.65, text=paste("norm.test.pv=",norm.std.residuals.m1.pv,
  sep=""),cex=.5,adj=.25)

 # plot M0 fitted values (X-axis) vs residuals of M0 (Y-axis)
 plot(unlist(fitted.m0.by.line),unlist(std.residuals.m0.by.line),ylim=c(-2.5,2.5),
  main=paste(targetID,hgnc,sep="|"),cex=.5,pch=19,cex.main=.75,
  xlab="fitted.m0",ylab="std.residuals.m0",las=2,col=rgb(1,0,0,.25))
 abline(h=0,lty=2,lwd=1.5)
 mtext(side=3,line=.65,text=paste("RMSPE=",
  RCV$m0.rmspe.avg[match(hgnc,RCV$HGNC.symbol)],sep=""),cex=.5,adj=.25)

 # plot response (X-axis) vs M0 fitted (Y-axis)
 plot(rep(response.by.line[1], length(fitted.m0.by.line[[1]])), fitted.m0.by.line[[1]],
  cex=.5,pch=19,col=rgb(1,0,0,.25),axes=T, ylab="fitted.m0", xlab="response",
  main=paste(targetID,hgnc,sep="|"),cex.main=.85,las=2,
  xlim=c(min(response.by.line)-.5,max(response.by.line)+.5),
  ylim=c(min(unlist(fitted.m0.by.line)),max(unlist(fitted.m0.by.line))))
 for(l in 2 : length(lines)){
  points(rep(response.by.line[l],length(fitted.m0.by.line[[l]])), fitted.m0.by.line[[l]],
   cex=.5, pch=19,col=rgb(1,0,0,.25))
 }

 # plot RNA vs PROT
 plot(X0[order(X0)],Y[order(X0)],col=rgb(1,0,0,1),cex.axis=.75,cex=.5,cex.main=.75,
  las=2,main=paste(targetID,hgnc,sep="|"),xlab="RNA",ylab="PROT",pch=19)
 mtext(paste("cor(RNA,PROT)",prot.rna.cor,sep="="),
  side=3,line=.5,cex=.65,adj=.25)

dev.off()

