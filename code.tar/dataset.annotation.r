
# date: 11/11/2014
# aim: 
# - retrieve genome-wide the longest 5'/3' UTR sequences associated with each gene
# - retrieve the association between gene symbols and UCSC trabscriot IDs with longest UTRs 
# Note that the representative transcript ID at 5' UTR may differ from that at 3' UTR for a gene.
#
# - retrieve mRNA/protein expresion profiles from NCI60 dataset (->NCI60.dataset.rda)
#
# - retrieve gene annotations for NCI60 genes (NCI60.annotation.rda). Annotations include:
#   HGNC symbol, Ensemblgene ID, chromosome, gene start, gene end, strand, 
#   UCSC with maximal 5' UTR, start of maximal 5' UTR, end of maximal 5' UTR,
#   UCSC with maximal 3' UTR, start of maximal 3' UTR, end of maximal 3' UTR
#
# out:
# - kgXref.geneSymbol.max.3utr.fa (similar for 5' UTR)
# - kgXref.geneSymbol.max.3utr.txt (similar for 3' UTR): tab-delimited file of 5'/3' representative UCSC IDs
# - kgXref.geneSymbol.max.53utr.txt: HGNC symbol, UCSC transcript ids of maximal 5'/3'UTR, 5'/3'UTR start, 5'/3'UTR end 
# - NCI60.annotation.rda
# - NCI60.dataset.rda
# - summarizedExperimentiBAQ.rda


require("GenomicRanges")
source("auxiliary.functions.r")


#---------------------------------
# genomic annotations from Ensembl Biomart
biomart = read.table("Ensembl.BioMart.v75.human.txt",header=TRUE,as.is=TRUE,sep="\t")


#-------------
# obtain mapping of UCSC transcripts to gene symbols 
idf = read.delim("../../annotation/UCSC.hg19.KnownToEnsembl.txt",
 header=TRUE,as.is=TRUE,sep="\t")
ref.geneSymbol = unique(idf$hg19.kgXref.geneSymbol)
kgXref.geneSymbol = list()
for(i in 1 : length(ref.geneSymbol)){
 kgXref.geneSymbol[[ref.geneSymbol[i]]] = 
  unique(idf$hg19.kgXref.kgID[is.na(match(idf$hg19.kgXref.geneSymbol,ref.geneSymbol[i]))==FALSE])
}

#-------------
# obtain 5'/3' UTR sequences in fasta format
utr3f = readLines("../../annotation/UCSC.hg19.GRCh37.3utr.fa")
utr5f = readLines("../../annotation/UCSC.hg19.GRCh37.5utr.fa")


###########################################################################
#
# retrueval of longest 5'/3' UTRs for all genes
# retrieval of 5'/3' UTR representative UCSC transcript IDs for all genes  
#
###########################################################################

#-------------
# obtain longest 5'/3'UTR sequences per gene and corresponding UCSC transcript IDs 
longest.utr(utr3f,"3utr")
longest.utr(utr5f,"5utr")

#---------------------------
# obtain associations between HGNC symbols and UCSC ids at the 5' and 3' UTRs

ucsc5utrMax = as.vector(read.table("kgXref.geneSymbol.max.5utr.txt",sep="\t",header=FALSE,as.is=TRUE)[,1])
ucsc3utrMax = as.vector(read.table("kgXref.geneSymbol.max.3utr.txt",sep="\t",header=FALSE,as.is=TRUE)[,1])

utr5intervals = get.utr.intervals(utr5f)
utr3intervals = get.utr.intervals(utr3f)

zrs=rep("NA",length(kgXref.geneSymbol))
out = data.frame(row.names=names(kgXref.geneSymbol),
  ucsc.5utr=zrs,ucsc.5utr.chr=zrs,ucsc.5utr.start=zrs,ucsc.5utr.end=zrs,
  ucsc.3utr=zrs,ucsc.3utr.chr=zrs,ucsc.3utr.start=zrs,ucsc.3utr.end=zrs,
  stringsAsFactors=F)
for(i in 1 : length(names(kgXref.geneSymbol))){
 ucsc5utr=intersect(kgXref.geneSymbol[[names(kgXref.geneSymbol)[i]]], 
  ucsc5utrMax)
 if(length(ucsc5utr)>0){
  out[i,1]=ucsc5utr
  out[i,2]=utr5intervals$chr[is.na(match(utr5intervals$id,ucsc5utr))==FALSE]
  out[i,3]=utr5intervals$start[is.na(match(utr5intervals$id,ucsc5utr))==FALSE]
  out[i,4]=utr5intervals$end[is.na(match(utr5intervals$id,ucsc5utr))==FALSE]
 }
 ucsc3utr=intersect(kgXref.geneSymbol[[names(kgXref.geneSymbol)[i]]],
  ucsc3utrMax)
 if(length(ucsc3utr)>0){
  out[i,5]=ucsc3utr
  out[i,6]=utr3intervals$chr[is.na(match(utr3intervals$id,ucsc3utr))==FALSE]
  out[i,7]=utr3intervals$start[is.na(match(utr3intervals$id,ucsc3utr))==FALSE]
  out[i,8]=utr3intervals$end[is.na(match(utr3intervals$id,ucsc3utr))==FALSE]
 }
}
write.table(out,file="kgXref.geneSymbol.max.53utr.txt",
 sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE)


#########################
#
# NCI60 mRNA/protein data
#
#########################

#----------------------------
# obtain the mapping between gene symbols and UCSC transcripts
kgXgeneSymbol = read.table("kgXref.geneSymbol.max.53utr.txt",
 header=TRUE,as.is=TRUE,sep="\t")

#---------------------------------
# NCI60 rna processed data
rna = read.delim("Table_S8_NCI60_transcriptome.txt",
 header=TRUE,comment.char="#",as.is=TRUE,sep="\t")
rna[,3] = gsub(" \\(includes.*\\)","",rna[,3])

#---------------------------------
# NCI60 protein processed data
prot = read.delim("Table_S3_NCI60_proteome.txt",header=TRUE,as.is=TRUE,sep="\t")

save(biomart,rna,prot,file="NCI60.dataset.rda")



###############################################################
#
# retrieval of ID mapping and genomic information for all genes 
# NCI60 files contained mapping between HGNC symbols and IPI IDs
# which is used to compile the general annotation file
#
################################################################

load("NCI60.dataset.rda")

#----------------------------
# retrieve IPI-HGNC relations by NCI60 protein profiles
symbol.start = as.numeric(sapply(prot$Fasta.headers, 
 function(x)(regexpr("Gene_Symbol",x)[1])))
ss = substr(prot$Fasta.headers[symbol.start != -1], 
 start=symbol.start[symbol.start != -1], stop=1000000L)
tmp = gsub("Gene_Symbol=","",as.vector(sapply(ss, function(x)(strsplit(x,
 " ")[[1]][1]))))
symbol = as.vector(sapply(tmp, function(x)(strsplit(x,";")[[1]][1])))
zrs = rep(0,length(symbol))
ipiHgncProt = data.frame(IPI=zrs,HGNC.symbol=zrs)
ipiHgncProt[,1] = prot$Accession[symbol.start != -1]
ipiHgncProt[,2] = symbol
ipiHgncProt = ipiHgncProt[is.na(ipiHgncProt[,1])==FALSE &
 is.na(ipiHgncProt[,2])==FALSE & is.na(match(ipiHgncProt[,2],"-"))==T,]

#----------------------------
# retrieve IPI-HGNC relations by NCI60 rna profiles
ipiHgncRna = unique(rna[,2:3])
ipiHgncRna = ipiHgncRna[is.na(ipiHgncRna[,1])==FALSE & is.na(ipiHgncRna[,2])==FALSE,]
colnames(ipiHgncRna) = c("IPI","HGNC.symbol")

#----------------------------
# union of IPI-HGNC relations
ipiHgnc = unique(rbind(ipiHgncProt,ipiHgncRna))


#----------------------------
# retrieve Biomart annotation for NCI60 profiled genes
l = dim(ipiHgnc)[1]
annotation = data.frame(ID = character(1),IPI = character(l),
 HGNC.symbol = character(l),Ensembl.Gene.ID = character(l),
 Chromosome.Name =  character(l),Gene.Start..bp. = integer(l),
 Gene.End..bp. = integer(l), Strand = character(l),
 UCSC.max5utr = character(l),UCSC.max5utr.start = integer(l),
 UCSC.max5utr.end = integer(l),UCSC.max3utr = character(l),
 UCSC.max3utr.start = integer(l),UCSC.max3utr.end = integer(l))

annotation$ID = paste("ID",1:l,sep="")
annotation$IPI = ipiHgnc[,1]
annotation$HGNC.symbol = ipiHgnc[,2]
annotation$Ensembl.Gene.ID = biomart$Ensembl.Gene.ID[match(ipiHgnc[,2],
 biomart$HGNC.symbol)]
annotation$Chromosome.Name = biomart$Chromosome.Name[match(ipiHgnc[,2],
 biomart$HGNC.symbol)]
annotation$Gene.Start..bp. = biomart$Gene.Start..bp.[match(ipiHgnc[,2],
 biomart$HGNC.symbol)]
annotation$Gene.End..bp. = biomart$Gene.End..bp.[match(ipiHgnc[,2],
 biomart$HGNC.symbol)]
annotation$Strand = biomart$Strand[match(ipiHgnc[,2],biomart$HGNC.symbol)]
annotation$UCSC.max5utr = kgXgeneSymbol$ucsc.5utr[match(ipiHgnc[,2],
 rownames(kgXgeneSymbol))]
annotation$UCSC.max5utr.start = kgXgeneSymbol$ucsc.5utr.start[match(ipiHgnc[,2], rownames(kgXgeneSymbol))]
annotation$UCSC.max5utr.end = kgXgeneSymbol$ucsc.5utr.end[match(ipiHgnc[,2],
 rownames(kgXgeneSymbol))]
annotation$UCSC.max3utr = kgXgeneSymbol$ucsc.3utr[match(ipiHgnc[,2],
 rownames(kgXgeneSymbol))]
annotation$UCSC.max3utr.start = kgXgeneSymbol$ucsc.3utr.start[match(ipiHgnc[,2],rownames(kgXgeneSymbol))]
annotation$UCSC.max3utr.end = kgXgeneSymbol$ucsc.3utr.end[match(ipiHgnc[,2],
 rownames(kgXgeneSymbol))]

# remove genes with incomplete genomic annotation
ind = apply(annotation[,4:8], 1, function(x) all(is.na(x)))
annotation = annotation[ !ind, ]

# rename annotations of genes profiled in NCI60
annotation.ipi.by.nci60 = annotation

#-------------------------------------
# retrieve Biomart annotations for genes not profiled in NCI60
HGNC = setdiff(biomart$HGNC.symbol,ipiHgnc[,2])
HGNC=HGNC[nchar(HGNC)>0]
l=length(HGNC[nchar(HGNC)>0])
annotation = data.frame(ID = character(1),IPI = character(l),
 HGNC.symbol = character(l),Ensembl.Gene.ID = character(l),
 Chromosome.Name =  character(l),Gene.Start..bp. = integer(l), 
 Gene.End..bp. = integer(l),Strand = character(l),
 UCSC.max5utr = character(l),UCSC.max5utr.start = integer(l),
 UCSC.max5utr.end = integer(l),UCSC.max3utr = character(l),
 UCSC.max3utr.start = integer(l),UCSC.max3utr.end = integer(l))

annotation$ID = paste("ID",(dim(annotation)[1]+1):
 (dim(annotation)[1]+length(HGNC)),sep="")
annotation$IPI = rep("NA",length=l)
annotation$HGNC.symbol = biomart$HGNC.symbol[match(HGNC,biomart$HGNC.symbol)]
annotation$Ensembl.Gene.ID = biomart$Ensembl.Gene.ID[match(HGNC,
 biomart$HGNC.symbol)]
annotation$Chromosome.Name = biomart$Chromosome.Name[match(HGNC,
 biomart$HGNC.symbol)]
annotation$Gene.Start..bp. = biomart$Gene.Start..bp.[match(HGNC,
 biomart$HGNC.symbol)]
annotation$Gene.End..bp. = biomart$Gene.End..bp.[match(HGNC,
 biomart$HGNC.symbol)]
annotation$Strand = biomart$Strand[match(HGNC,biomart$HGNC.symbol)]
annotation$UCSC.max5utr = kgXgeneSymbol$ucsc.5utr[match(HGNC,
 rownames(kgXgeneSymbol))]
annotation$UCSC.max5utr.start = kgXgeneSymbol$ucsc.5utr.start[match(HGNC,
 rownames(kgXgeneSymbol))]
annotation$UCSC.max5utr.end = kgXgeneSymbol$ucsc.5utr.end[match(HGNC,
 rownames(kgXgeneSymbol))]
annotation$UCSC.max3utr = kgXgeneSymbol$ucsc.3utr[match(HGNC,
 rownames(kgXgeneSymbol))]
annotation$UCSC.max3utr.start = kgXgeneSymbol$ucsc.3utr.start[match(HGNC,
 rownames(kgXgeneSymbol))]
annotation$UCSC.max3utr.end = kgXgeneSymbol$ucsc.3utr.end[match(HGNC,
 rownames(kgXgeneSymbol))]

# remove genes with incomplete genomic coordinates of the gene symbol
ind = apply(annotation[,4:8],1, function(x) all(is.na(x)))
annotation = annotation[ !ind, ]

annotation.ipi.na.by.nci60 = annotation

#--------------------------
# union of Biomart annotations for genes non-profiled/profiled in NCI60
annotation = rbind(annotation.ipi.by.nci60,annotation.ipi.na.by.nci60)

save(annotation,file="NCI60.annotation.rda")


###############################
# 
# summarizedExperiment object
#
###############################

load("NCI60.annotation.rda")

#-------------------------
# get gene identifiers in either RNA or protein assay
g.rna = annotation$ID[is.na(match(annotation$HGNC.symbol,rna[,3]))==FALSE]
g.prot = annotation$ID[is.na(match(annotation$IPI,prot$Accession))==FALSE]
g = union(g.rna,g.prot)
annotation = annotation[is.na(match(annotation$ID,g))==FALSE,]
# sort annotation by the order of genes in g
annotation = annotation[match(g, annotation$ID),]


#-------------------------
# summarize probe-level RNA intensity values (log10) to gene-level values
expr.rna = data.frame()
for(i in 1 : length(g)){
 # columns 9-67 correspond to NCI60 cell lines
 tmp = rna[is.na(match(rna[,3],
  annotation$HGNC.symbol[is.na(match(annotation$ID,g[i]))==FALSE]))==FALSE,9:67]

 if(dim(tmp)[1]==0){ 
  expr.rna = rbind(expr.rna, rep(NA,length(colnames(rna)[9:67]))) 
 }
 if(dim(tmp)[1]!=0){ 
  tmp.unlog = 10^tmp
  expr.rna = rbind(expr.rna,log10(colMeans(tmp.unlog))) 
 }
  show(i)
}
colnames(expr.rna) = colnames(rna)[9:67]
rownames(expr.rna) = g


#------------------------ 
# get protein values (log10) by iBAQ quantification
expr.prot = data.frame() 
for(i in 1 : length(g)){
 tmp = prot[is.na(match(prot$Accession,annotation$IPI[is.na(match(annotation$ID,
  g[i]))==FALSE]))==FALSE,grepl("iBAQ",colnames(prot))==TRUE]

 if(dim(tmp)[1]==0){ 
  expr.prot = rbind(expr.prot, rep(NA,length(colnames(prot)[grepl("iBAQ",
   colnames(prot))==TRUE]))) 
 } 
 if(dim(tmp)[1]!=0){ 
  tmp[tmp==0]=NA
  # log10(NA) = NA; if all column's elements are NAs then the mean is NaN
  tmpMeans=log10(colMeans(tmp,na.rm=T))
  # replace NaN values by NA
  tmpMeans[is.nan(tmpMeans)==T]=NA  
  expr.prot = rbind(expr.prot,tmpMeans) 
 }
 show(i)
}
colnames(expr.prot) = colnames(prot)[grepl("iBAQ",colnames(prot))==TRUE]
colnames(expr.prot) = gsub("iBAQ_","",colnames(expr.prot))
rownames(expr.prot) = g


#-------------------------
# make summarizedExperiment object
rowData <- GRanges(
 seqnames = annotation$Chromosome.Name,
 ranges = IRanges(start=annotation$Gene.Start..bp.,
 end = annotation$Gene.End..bp., 
 names = annotation$ID),
 strand = annotation$Strand)
colData <- DataFrame(row.names=colnames(expr.rna),ID=colnames(expr.rna))
sset <- SummarizedExperiment(
 assays=list(
  as.matrix(expr.rna,row.names=annotation$ID),
  as.matrix(expr.prot,row.names=annotation$ID)
 ),
 rowData=rowData,
 colData=colData)

save(sset,file="summarizedExperimentiBAQ.rda")



