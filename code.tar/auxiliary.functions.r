
library(caret)
library(cvTools)
library(glmnet)
library(impute)
library(MASS)

########################
#
# model building functions
#
########################

  fit <- function (R,X){
   if(is.matrix(X)==FALSE){
    df=as.data.frame(cbind(R,X))
    colnames(df)=c("Y","Predictor")
    m=rlm(Y  ~  Predictor, data=df)
   }
   if(is.matrix(X)==TRUE){
    df=as.data.frame(cbind(R,X))
    colnames(df)=c("Y",colnames(X))
    m=rlm(Y  ~ ., data=df)
   }
   return(m)
  }

 
  fit_predict <- function (Rtrain,Rpredict,Xtrain,Xpredict){
   if(is.matrix(Xtrain)==FALSE){
    df=as.data.frame(cbind(Rtrain,Xtrain))
    colnames(df)=c("Y","Predictor")
    m=rlm(Y  ~  Predictor, data=df)
    new.df <- data.frame(Predictor=Xpredict)
    Y.predict=predict.lm(m,new.df, interval="confidence",se.fit=T)
   }
   if(is.matrix(Xtrain)==TRUE){
    df=as.data.frame(cbind(Rtrain,Xtrain))
    colnames(df)=c("Y",colnames(Xtrain))
    m=rlm(Y  ~ ., data=df)
    new.df <- data.frame(Xpredict)
    Y.predict=predict.lm(m,new.df, interval="confidence",se.fit=T)
   }
   return(Y.predict)
 }

# return estimate and confidence intervals of individual model ptredictors
conf_interval <- function (m,alpha){
 estimate = summary(m)$coefficients[,1]
 estimate.se = summary(m)$coefficients[,2]
 critical.value = qt(1-(alpha/2),summary(m1)$fstatistic[3])
 conf.interval = cbind(estimate,estimate-(critical.value*estimate.se),
  estimate+(critical.value*estimate.se))
 return(conf.interval)
}


# this function runs two embedded CV procedures: 
# - the outer CV (folds=5) is used to estimate the prediction error
# - the inner CV (folds=3) within the training data of each fold of the
#   outer CV is used to estimate the regression coefficients with regularization
cross_validation_with_penalty_tunel <- function (K,R,X0,X1,Y,penalty){

 # X,Y is Xtrain,Ytrain in the cross-validation for prediction error w/o penalty
 # penalty = 0 is ridge penalty 
 rmspe.ratio=c();rmspe.ratio.se=c();
 m0.fitted=data.frame(); m1.fitted=data.frame();response=data.frame();
 m0.rmspe=c(); m0.rmspe.se=c(); m1.rmspe=c(); m1.rmspe.se=c();
 cvm=c(); cvsd=c(); nzero=c(); lambda.min=c(); m1.coef=list()
 cor.rna.prot.wo.impute = c(); cor.rna.prot.impute = c();

 for(r in 1 : R){
  folds=cvFolds(length(Y), K = K, type = "random")
  tmp=cbind(folds$which,folds$subsets[,1])
  for(k in 1 : K){
   idx.predict=tmp[tmp[,1]==k,2]
   idx.train=tmp[tmp[,1]!=k,2]
   X0.train=X0[idx.train]
   if(is.matrix(X1)==T){X1.train=X1[idx.train,]}
   if(is.matrix(X1)==F){X1.train=X1[idx.train]}
   Y.train=Y[idx.train]
   X0.predict=X0[idx.predict]
   if(is.matrix(X1)==T){X1.predict=X1[idx.predict,]}
   if(is.matrix(X1)==F){X1.predict=X1[idx.predict]}
   Y.predict=Y[idx.predict]
   
   # calculate RNA vs PROT correlation before imputation
   cor.wo.impute=cor.test(X0.train,Y.train)$estimate
   cor.rna.prot.wo.impute=c(cor.rna.prot.wo.impute,cor.wo.impute)

   # imputation of N/A values in training sub-matrix
   Z1.train=t(as.matrix(cbind(Y.train,X1.train)))
   Z1.train.knn = t(impute.knn(Z1.train)$data)
   Y.train=Z1.train.knn[,1]
   X1.train=Z1.train.knn[,-1]

   # imputation of N/A values in prediction sub-matrix
   Z1.predict=t(as.matrix(cbind(Y.predict,X1.predict)))
   Z1.predict.knn = t(impute.knn(Z1.predict)$data)
   Y.predict=Z1.predict.knn[,1]
   X1.predict=Z1.predict.knn[,-1]

    
   # skip prediction if RNA vs PROT correlation (after imputation) is low
   cor.impute=cor.test(X0.train,Y.train)$estimate

   # do k-fold cross-validation and return:
   # selected lambda (value of lambda that gives minimum cvm)
   # mean cross-validated error at selected lambda
   # estimate of standadrd error of cvm at selected lambda
   # number of non-zero coefficients at selected lambda 
  
   cvob=cv.glmnet(X1.train, Y.train, nfolds=3, alpha=penalty)
   m1.coef[[k*r]] = coef(cvob, s="lambda.min")[,1]
   lambda.min = c(lambda.min,cvob$lambda.min)
   cvm = c(cvm,cvob$cvm[match(cvob$lambda.min,cvob$lambda)])
   cvsd = c(cvsd,cvob$cvsd[match(cvob$lambda.min,cvob$lambda)])
   nzero = c(nzero,cvob$nzero[match(cvob$lambda.min,cvob$lambda)])

   # predict values from fitted glmnet object
   m1.predict = predict(cvob,newx=X1.predict, s="lambda.min", se.fit=T)

   # RMSPE for M1 (Root Mean Squared Prediction Error)
   rmspe.M1 = NA
   residuals=m1.predict-Y.predict
   rmspe = signif(as.numeric(sqrt(mean(residuals^2))),digits=3)
   if(is.na(rmspe)==FALSE){ rmspe.M1 = rmspe }
   m1.rmspe = c(m1.rmspe,rmspe.M1)
   m1.fitted =rbind(m1.fitted,cbind(names(Y.predict),m1.predict[,1]))

   # fit model M0
   m0=fit(Y.train,X0.train)
   m0.predict = fit_predict(Y.train,Y.predict,X0.train,X0.predict)
   m0.fitted = rbind(m0.fitted, cbind(names(Y.predict),m0.predict$fit[,1])) 

   # RMSPE for M0
   rmspe.M0 = signif(as.numeric(rmspe(Y.predict, m0.predict$fit[,1],
    includeSE=T)[1]),digits=3)
   m0.rmspe = c(m0.rmspe,rmspe.M0)

   # RMSPE ratio
   rmspe.ratio = c(rmspe.ratio,signif(rmspe.M0/rmspe.M1,digits=3))

   # collect Y.predict values in order to show diagnostic plots
   response = rbind(response,cbind(names(Y.predict),as.numeric(Y.predict)))


   # correlation RNA vs prot (training data)
   cor.rna.prot.impute = c(cor.rna.prot.impute,
    cor.test(X0.train,Y.train)$estimate) 
  }
 }

 if(is.null(m1.rmspe)==FALSE & is.null(m0.rmspe)==FALSE){
  # mean of RMSPE over K folds and R repetitions
  m1.rmspe.avg = signif(mean(m1.rmspe[is.na(m1.rmspe)==FALSE]),digits=3)
  m0.rmspe.avg = signif(mean(m0.rmspe[is.na(m0.rmspe)==FALSE]),digits=3)

  # ratio of M0 RMSPE average to M1 RMSPE average over K folds and R repetitions
  rmspe.ratio.avg = signif(m0.rmspe.avg/m1.rmspe.avg, digits=3)

  out = list(list(m0.rmspe = m0.rmspe,m1.rmspe = m1.rmspe,
   m0.coef.n=length(summary(m0)$coefficients[,1]),m1.coef.n=nzero,
   cvm=signif(cvm,digits=2),cvsd=signif(cvsd,digits=2),
   lambda.min=signif(lambda.min,digits=2),rmspe.ratio = rmspe.ratio,
   m0.rmspe.avg = m0.rmspe.avg,m1.rmspe.avg = m1.rmspe.avg,
   rmspe.ratio.avg = rmspe.ratio.avg,n.iter=length(m1.rmspe)),m1.coef,
   response,m0.fitted,m1.fitted)
 }

 if(is.null(m1.rmspe)==TRUE | is.null(m0.rmspe)==TRUE){
  out=rep("NA",times=15) # priam era 12
 }
 return(out)
 
}


################################################################
#
# retrieve start/stop positions of sequences in input fasta file
#
################################################################

get.utr.intervals <- function(utrf){
 tmp=utrf[grepl(">",utrf)==TRUE]
 id = gsub(">hg19_knownGene_","",as.vector(sapply(tmp,function(x)(strsplit(x," "))[[1]][1])))
 coords = as.vector(sapply(tmp,function(x)(strsplit(x," "))[[1]][2]))
 start = as.vector(sapply(gsub("range=chr.*:","",coords),function(x)(strsplit(x,"-"))[[1]][1]))
 end = as.vector(sapply(gsub("range=chr.*:","",coords),function(x)(strsplit(x,"-"))[[1]][2]))
 chr = as.vector(sapply(gsub("range=","",coords),function(x)(strsplit(x,":"))[[1]][1]))
 return(data.frame(id=id,chr=chr,start=start,end=end))
}
 

################################################################
#
# retrieve the longest UTR for each gene in the input fasta file 
#
################################################################

get.longest.utr <- function(utrf,utr.type){

 # output files
 idf = paste("kgXref.geneSymbol.max.",utr.type,".txt",sep="") 
 seqf = paste("kgXref.geneSymbol.max.",utr.type,".fa",sep="")
 
 # index of headers beginning each UTR sequence in the fasta file
 tmp = c(); j=0;
 indXkg = data.frame()
 for(i in 1 : length(utrf)){
  if(grepl(">", utrf[i])==TRUE){ 
   tmp = c(tmp, utrf[i])
   j=j+1
   indXkg[j,1] = gsub(">hg19_knownGene_","",strsplit(utrf[i],"\\s")[[1]][1])
   indXkg[j,2] = i 
  }
 }

 ## transcript id, start, end UTR positions 
 id = gsub(">hg19_knownGene_","",
  as.vector(sapply(tmp,function(x)(strsplit(x," "))[[1]][1])))
 coords = as.vector(sapply(tmp,function(x)(strsplit(x," "))[[1]][2]))
 start = as.vector(sapply(gsub("range=chr.*:","",coords), 
  function(x)(strsplit(x,"-"))[[1]][1]))
 end = as.vector(sapply(gsub("range=chr.*:","",coords), 
  function(x)(strsplit(x,"-"))[[1]][2]))

 ## transcript of maximal UTR length per unique geneSymbol 
 transcriptML = list() 
 for(i in 1 : length(ref.geneSymbol)){
  tmp = id[is.na(match(id,kgXref.geneSymbol[[ref.geneSymbol[i]]]))==FALSE]
  if(length(tmp)>0){
  utrl = as.numeric(end[match(tmp,id)])-as.numeric(start[match(tmp, id)])
   transcriptML[[ref.geneSymbol[i]]] = tmp[match(max(utrl), utrl)] 
  }
 }
 out = unique(as.vector(unlist(transcriptML))
  [nchar(as.vector(unlist(transcriptML)))>0])

 # print UCSC transcript IDs with longest UTR per gene 
 write.table(out, file=idf, quote=FALSE, col.names=FALSE,row.names=FALSE,sep="\t")

 # print longest UTR sequences by line
 for(i in 1 : length(out)){
  startL = indXkg[grep(out[i],indXkg[,1]),2]+1
  if((grep(out[i],indXkg[,1])+1)<=dim(indXkg)[1]){ 
   endL = indXkg[grep(out[i],indXkg[,1])+1,2]-1 
  }
  if((grep(out[i],indXkg[,1])+1)>dim(indXkg)[1]){
   endL = length(utrf)
  }
  tmp = c()
  for(j in startL : endL){
   tmp = c(tmp,utrf[j])
  }
  sequence = paste(tmp,collapse="")
  write.table(cbind(utrf[grep(out[i],utrf)], sequence),
   sep="\t",append=TRUE,file=seqf,quote=FALSE,row.names=FALSE,col.names=FALSE)
 }
}


