
Last updated 11/11/2014

//
script-name: auxiliary.functions.r
script-description: 
 collection of functions for UTR sequence retrieval, gene annotation and model fitting  
//

//
script-name: dataset.annotation.r
script-description: 
 - retrieve genome-wide the longest 5'/3' UTR sequences associated with each gene

 - retrieve the association between gene symbols and UCSC trabscriot IDs with longest UTRs 
 Note that the representative transcript ID at 5' UTR may differ from that at 3' UTR for a gene.

 - retrieve mRNA/protein expresion profiles from NCI60 dataset (->NCI60.dataset.rda)

 - assemble mRNA/protein data ina SummerizedExperiment object with two components each of which
   contains a matrix of gene expression profiles at either mRNA or protein level 
  (->summarizedExperimentiBAQ.rda)

 - retrieve gene annotations for NCI60 genes (NCI60.annotation.rda). Annotations include:
   HGNC symbol, Ensemblgene ID, chromosome, gene start, gene end, strand, 
   UCSC with maximal 5' UTR, start of maximal 5' UTR, end of maximal 5' UTR,
   UCSC with maximal 3' UTR, start of maximal 3' UTR, end of maximal 3' UTR
//

//
script-name: model.build.r
script-description: 
  For a single gene of example,fit protein levels by null model and full model. 
  Null model uses the mRNA level of the gene to model while the full model add 
  to the gene's mRNA level also the protein levels of the RBPs inferred to bind the gene to model.

  Null models are fitted by robust linear regression. Full models are fitted by 
  ridge penalty linear regression because the number of predictors per gene is
  high with respect to the number of available samples (59 cell lines).

  Thescript provide diagnostic plots of fitted models for the gene of example.
 
//

